//Entrega 1 abb
//Grupo: G21
//Alumnos: Cambiano Agustín - Gualdieri Sofía
//Correctora: Dvorkin Camila


#define _POSIX_C_SOURCE 200809L
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "abb.h"
#include "pila.h"


#define RECORRIDO_ASCENDENTE "asc"
#define RECORRIDO_DESCENDENTE "desc"


typedef struct nodo{
  struct nodo* izquierda;
  struct nodo* derecha;
  char* clave1;
  char* clave2;
  void* dato;
}nodo_t;



struct abb{
  nodo_t* raiz;
  size_t cantidad;
  abb_comparar_clave_t comparar_clave1;
  abb_comparar_clave_t comparar_clave2;
  abb_destruir_dato_t destruir_dato;
};


struct abb_iter{
  pila_t* pila;
};


//Devuelve un puntero a un nodo inicializado con los valores pasados
static nodo_t* crear_nodo(const char* clave1, const char* clave2, void* dato){

  nodo_t* nodo=malloc(sizeof(nodo_t));

  if (!nodo) {
    return NULL;
  }

  nodo->clave1=strdup(clave1);

  if (!nodo->clave1) {
    free(nodo);
    return NULL;
  }

  nodo->clave2=strdup(clave2);

  if (!nodo->clave2) {
    free(nodo->clave1);
    free(nodo);
    return NULL;
  }

  nodo->dato=dato;
  nodo->izquierda=NULL;
  nodo->derecha=NULL;

  return nodo;

}


//libera la memoria asignada a la clave y al nodo y devuelve
//el dato almacenado
void* destruir_nodo(nodo_t* nodo){

  void* dato=nodo->dato;
  free(nodo->clave1);
  free(nodo->clave2);
  free(nodo);

  return dato;

}


//Devuelve la cantidad de hijos que tiene un nodo
size_t cantidad_de_hijos(nodo_t* nodo){

  size_t cantidad=0;

  if (nodo->derecha!=NULL) {
    cantidad++;
  }

  if (nodo->izquierda!=NULL) {
    cantidad++;
  }

  return cantidad;

}



//Devuelve un puntero al nodo con la clave buscada
nodo_t* _buscar_nodo_y_padre(nodo_t** actual, nodo_t* padre , const char* clave1, const char* clave2, abb_comparar_clave_t comparar_clave1, abb_comparar_clave_t comparar_clave2){

  if (!(*actual)) {
    return padre;
  }

  if (!comparar_clave1((*actual)->clave1, clave1)) {
    if (!comparar_clave2((*actual)->clave2, clave2)) {
      return padre;
    }else{
      padre=*actual;
      if(comparar_clave2(clave2, (*actual)->clave2)>0){
        *actual=(*actual)->derecha;
        return _buscar_nodo_y_padre(actual, padre, clave1, clave2, comparar_clave1, comparar_clave2);
      }
      if(comparar_clave2(clave2, (*actual)->clave2)<0){
        *actual=(*actual)->izquierda;
        return _buscar_nodo_y_padre(actual, padre, clave1, clave2, comparar_clave1, comparar_clave2);
      }
    }
  }
  padre=*actual;

  if (comparar_clave1(clave1, (*actual)->clave1)>0) {
    *actual=(*actual)->derecha;
    return _buscar_nodo_y_padre(actual, padre, clave1, clave2, comparar_clave1, comparar_clave2);
  }

  *actual=(*actual)->izquierda;
  return _buscar_nodo_y_padre(actual, padre, clave1, clave2, comparar_clave1, comparar_clave2);

}


void intercambiar_nodos(nodo_t* nodo1, nodo_t* nodo2){

  nodo_t auxiliar=*nodo1;

  nodo1->clave1=nodo2->clave1;
  nodo1->clave2=nodo2->clave2;
  nodo1->dato=nodo2->dato;

  nodo2->clave1=auxiliar.clave1;
  nodo2->clave2=auxiliar.clave2;
  nodo2->dato=auxiliar.dato;

}



nodo_t* buscar_nodo_y_padre(const abb_t* arbol, nodo_t** nodo, const char* clave1, const char* clave2){

  *nodo=arbol->raiz;

  return _buscar_nodo_y_padre(nodo, NULL, clave1, clave2, arbol->comparar_clave1, arbol->comparar_clave2);

}



void _abb_destruir(nodo_t* nodo, abb_destruir_dato_t destruir_dato){

  if (!nodo) {
    return;
  }

  _abb_destruir(nodo->izquierda, destruir_dato);
  _abb_destruir(nodo->derecha, destruir_dato);

  void* dato=destruir_nodo(nodo);

  if (destruir_dato!=NULL) {
    destruir_dato(dato);
  }

}


//Intercambia el hijo del padre pasado por un remplazante
//No detecta errores, por lo que se deberá pasar un nodo
//que sea realmente un hijo para que funcione bien
void remplazar_hijo(nodo_t* padre, nodo_t* a_remplazar, nodo_t* remplazante){

  if (padre->izquierda==a_remplazar) {
    padre->izquierda=remplazante;
  }else{
    padre->derecha=remplazante;
  }

}


//Devuelve un puntero al hijo de un nodo que solo tiene
//un hijo
nodo_t* obtener_hijo(nodo_t* nodo){

  if (nodo->izquierda!=NULL) {
    return nodo->izquierda;
  }

  return nodo->derecha;

}


//Devuelve el nodo mas chico de un arbol o subarbol
nodo_t* buscar_menor(nodo_t* nodo, nodo_t** padre){

  if (!nodo->izquierda) {
    return nodo;
  }

  *padre=nodo;

  return buscar_menor(nodo->izquierda,padre);

}



bool _abb_in_order_ascendente(nodo_t* actual, bool visitar(void *, void *), void *extra, abb_comparar_clave_t comparar_clave1, char* desde, char* hasta){

  if (!actual) {
    return true;
  }


  /*
  if (actual->izquierda!=NULL) {
  if (comparar_clave1(actual->izquierda->clave1, desde)>=0) {
  if (!_abb_in_order_ascendente(actual->izquierda, visitar, extra, comparar_clave1, desde, hasta)) {
  return false;
}
}
}


if ((comparar_clave1(actual->clave1, hasta) <= 0)&&(comparar_clave1(actual->clave1, desde) >= 0)) {
if (!visitar(actual->dato, extra)) {
return false;
}
}

if (actual->derecha!=NULL) {
if (comparar_clave1(actual->derecha->clave1, hasta)<=0) {
if (!_abb_in_order_ascendente(actual->derecha, visitar, extra, comparar_clave1, desde, hasta)) {
return false;
}
}else{
return false;
}
}
  */


  if (comparar_clave1(actual->clave1, desde)>=0) {
    if (!_abb_in_order_ascendente(actual->izquierda, visitar, extra, comparar_clave1, desde, hasta)) {
      return false;
    }
  }


  if ((comparar_clave1(actual->clave1, hasta) <= 0)&&(comparar_clave1(actual->clave1, desde) >= 0)) {
    if (!visitar(actual->dato, extra)) {
      return false;
    }
  }


  if (comparar_clave1(actual->clave1, hasta)<=0) {
    if (!_abb_in_order_ascendente(actual->derecha, visitar, extra, comparar_clave1, desde, hasta)) {
      return false;
    }
  }

  return true;

}




bool _abb_in_order_descendente(nodo_t* actual, bool visitar(void *, void *), void *extra, abb_comparar_clave_t comparar_clave1, char* desde, char* hasta){

  if (!actual) {
    return true;
  }

		/*
  if (actual->derecha!=NULL) {
    if (comparar_clave1(actual->derecha->clave1, hasta)<=0) {
      if (!_abb_in_order_descendente(actual->derecha, visitar, extra, comparar_clave1, desde, hasta)) {
        return false;
      }
    }
  }


  //if (comparar_clave1(actual->clave1, desde)>=0) {
  //  if (!visitar(actual->dato, extra)) {
  //				return false;
  // }
  //}



  if ((comparar_clave1(actual->clave1, desde) >= 0)&&(comparar_clave1(actual->clave1, hasta) <= 0)) {
    if (!visitar(actual->dato, extra)) {
      return false;
    }
  }


  if (actual->izquierda!=NULL) {
    if (comparar_clave1(actual->izquierda->clave1, desde)>=0) {
      if (!_abb_in_order_descendente(actual->izquierda, visitar, extra, comparar_clave1, desde, hasta)) {
        return false;
      }
    }else{
      return false;
    }
  }
		*/

	if (comparar_clave1(actual->clave1, hasta) <= 0) {
    if (!_abb_in_order_descendente(actual->derecha, visitar, extra, comparar_clave1, desde, hasta)) {
      return false;
    }
	}

	if ((comparar_clave1(actual->clave1, desde) >= 0) && (comparar_clave1(actual->clave1, hasta) <= 0)) {
		if (!visitar(actual->dato, extra)) {
			return false;
		}
	}

  if (comparar_clave1(actual->clave1, desde) >= 0) {
    if (!_abb_in_order_descendente(actual->izquierda, visitar, extra, comparar_clave1, desde, hasta)) {
      return false;
    }
  }

	return true;

}




abb_t* abb_crear(abb_comparar_clave_t cmp1, abb_comparar_clave_t cmp2, abb_destruir_dato_t destruir_dato){

  abb_t* arbol=malloc(sizeof(abb_t));

  if (!arbol) {
    return NULL;
  }

  arbol->raiz=NULL;
  arbol->comparar_clave1=cmp1;
  arbol->comparar_clave2=cmp2;
  arbol->destruir_dato=destruir_dato;
  arbol->cantidad=0;

  return arbol;

}


bool abb_guardar(abb_t *arbol, const char *clave1, const char *clave2, void *dato){

  nodo_t* nodo;
  nodo_t* padre=buscar_nodo_y_padre(arbol, &nodo, clave1, clave2);

  if (!nodo) {
    nodo=crear_nodo(clave1, clave2, dato);

    if (!nodo) {
      return false;
    }

    arbol->cantidad++;

    if (!arbol->raiz) {
      arbol->raiz=nodo;
      return true;
    }

    if (arbol->comparar_clave1(nodo->clave1, padre->clave1)>0) {
      padre->derecha=nodo;
    }else if(arbol->comparar_clave1(nodo->clave1, padre->clave1)<0){
      padre->izquierda=nodo;
    }else{
      if (arbol->comparar_clave2(nodo->clave2, padre->clave2)>0) {
        padre->derecha=nodo;
      }else{
        padre->izquierda=nodo;
      }
    }

    return true;
  }

  if (arbol->destruir_dato!=NULL) {
    arbol->destruir_dato(nodo->dato);
  }
  nodo->dato=dato;

  return true;

}


void *abb_borrar(abb_t *arbol, const char *clave1, const char *clave2){

  nodo_t* a_borrar;

  nodo_t* padre=buscar_nodo_y_padre(arbol, &a_borrar, clave1, clave2);

  if (!a_borrar) {
    return NULL;
  }

  arbol->cantidad--;

  size_t cantidad_hijos = cantidad_de_hijos(a_borrar);
  if (cantidad_hijos==0) {

    if (!padre) {
      arbol->raiz=NULL;
    }else{
      remplazar_hijo(padre, a_borrar, NULL);
    }

  }else if(cantidad_hijos==1){

    if (!padre) {
      arbol->raiz=obtener_hijo(a_borrar);
    }else{
      remplazar_hijo(padre, a_borrar, obtener_hijo(a_borrar));
    }

  }else{

    //en caso de que el remplazante sea hijo del nodo a borrar
    nodo_t* padre_remplazante=a_borrar;

    nodo_t* remplazante=buscar_menor(a_borrar->derecha, &padre_remplazante);

    intercambiar_nodos(a_borrar, remplazante);

    a_borrar=remplazante;
    remplazar_hijo(padre_remplazante, a_borrar, a_borrar->derecha);

  }

  return destruir_nodo(a_borrar);

}


void *abb_obtener(const abb_t *arbol, const char *clave1, const char *clave2){

  if ((!clave1)||(!clave2)) {
    return NULL;
  }

  nodo_t* a_buscar;
  buscar_nodo_y_padre(arbol, &a_buscar, clave1, clave2);

  if (!a_buscar) {
    return NULL;
  }

  return a_buscar->dato;

}


bool abb_pertenece(const abb_t *arbol, const char *clave1, const char *clave2){

  nodo_t* a_buscar;
  buscar_nodo_y_padre(arbol, &a_buscar, clave1, clave2);

  return a_buscar!=NULL;

}


size_t abb_cantidad(abb_t *arbol){

  return arbol->cantidad;

}


void abb_destruir(abb_t *arbol){

  _abb_destruir(arbol->raiz, arbol->destruir_dato);
  free(arbol);

}



void abb_in_order(abb_t *arbol, bool visitar(void *, void *), void *extra, char* desde, char* hasta, char* orden){

  if (!strcmp(orden, RECORRIDO_DESCENDENTE)) {
    _abb_in_order_descendente(arbol->raiz, visitar, extra, arbol->comparar_clave1, desde, hasta);
  }else{
    _abb_in_order_ascendente(arbol->raiz, visitar, extra, arbol->comparar_clave1, desde, hasta);
  }

}


bool apilar_izquierdos(pila_t* pila, nodo_t* nodo){

  if (!nodo) {
    return true;
  }

  return pila_apilar(pila, nodo)&&apilar_izquierdos(pila, nodo->izquierda);

}



abb_iter_t *abb_iter_in_crear(const abb_t *arbol){

  abb_iter_t* iter = malloc(sizeof(abb_iter_t));

  if(iter == NULL){
    return NULL;
  }

  iter->pila = pila_crear();

  if(!iter->pila){
    free(iter);
    return NULL;
  }

  if(arbol->raiz!=NULL){
    if (!apilar_izquierdos(iter->pila, arbol->raiz)) {
      abb_iter_in_destruir(iter);
      return NULL;
    }
  }

  return iter;

}


bool abb_iter_in_avanzar(abb_iter_t *iter){

  if (abb_iter_in_al_final(iter)) {
    return false;
  }

  nodo_t* actual = pila_desapilar(iter->pila);
  if(actual->derecha!=NULL){
    if (!apilar_izquierdos(iter->pila, actual->derecha)) {
      return false;
    }
  }

  return true;
}


cstring_t*  abb_iter_in_ver_actual(const abb_iter_t *iter){

  if (abb_iter_in_al_final(iter)) {
    return NULL;
  }

  nodo_t* actual=pila_ver_tope(iter->pila);

  cstring_t* claves=malloc(sizeof(cstring_t)*2);

  if (!claves) {
    return NULL;
  }

  claves[0]=(cstring_t)actual->clave1;
  claves[1]=(cstring_t)actual->clave2;

  return claves;

}


bool abb_iter_in_al_final(const abb_iter_t *iter){

  return pila_esta_vacia(iter->pila);

}



void abb_iter_in_destruir(abb_iter_t* iter){

  pila_destruir(iter->pila);
	free(iter);

}
