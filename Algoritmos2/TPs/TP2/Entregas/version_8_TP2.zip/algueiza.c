//Entrega 1 TP2
//Correctora: Camila Dvorkin
//Grupo: G21
//Alumnos: Cambiano Agustín - Gualdieri Sofía



#define _POSIX_C_SOURCE 200809L
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

#include "strutil.h"
#include "hash.h"
#include "abb.h"
#include "vuelo.h"
#include "contador.h"
#include "heap.h"
#include "lista.h"


#define PROCESO_REALIZADO_CON_EXITO 0
#define ERROR_CON_MEMORIA_DINAMICA -1
#define CANTIDAD_DE_PARAMETROS_ERRONEA -2
#define TIPO_DE_PARAMETRO_INCORRECTO -3
#define NO_SE_PUDO_ABRIR_EL_ARCHIVO -4
#define SE_ACABO_EL_ARCHIVO -5
#define COMANDO_INVALIDO -6
#define VUELO_INEXISTENTE -7


#define SEPARADOR_ENTRADA_ESTANDAR ' '
#define SEPARADOR_DATOS_VUELOS ','
#define AGREGAR_ARCHIVO "agregar_archivo"
#define VER_TABLERO "ver_tablero"
#define INFO_VUELO "info_vuelo"
#define PRIORIDAD_VUELOS "prioridad_vuelos"
#define BORRAR "borrar"

#define ORDEN_ASCENDENTE "asc"
#define ORDEN_DESCENDENTE "desc"

#define SEPARADOR_DIA_HORA 'T'
#define SEPARADOR_DIA '-'
#define SEPARADOR_HORA ':'
#define FECHA_VALIDA 1
#define FECHA_INVALIDA 0


typedef int (*comando_t)(hash_t*, abb_t*, char**);


typedef struct lista_e_indicador{
  lista_t* lista;
  bool indicador;
}lista_e_indicador_t;



int obtener_entero(char* cadena){

  if (cadena[0]=='-') {
    return -atoi(cadena+1);
  }

  return atoi(cadena);

}



bool es_un_entero(char* cadena){

  size_t largo_cadena= strlen(cadena);

  //ascii 0: 48
  //ascii 9: 57
  int primer_digito=0;

  if (cadena[0]=='-') {
    primer_digito=1;

    if (largo_cadena==1) {
      return false;
    }
  }

  for (size_t i = primer_digito; i < largo_cadena; i++) {
    if ((cadena[i]<48)||(cadena[i]>57)) {
      return false;
    }
  }

  return true;
}



void imprimir_arreglo_de_cadenas(const char** cadenas) {
  size_t i=0;

  while (cadenas[i]!=NULL) {
    printf("%s", cadenas[i]);
    if (cadenas[i+1]!=NULL) {
      printf(" ");
    }
    i++;
  }

  printf("\n");

}




//Devuelve un numero mayor a 0 si la prioridad de vuelo1
//es menor que la de vuelo2, si es mayor devuelve un numero
//menor a 0 y si son iguales devuelve 0
int mayor_prioridad_inversa(const void* vuelo1, const void* vuelo2){

  size_t prioridad1=vuelo_prioridad((vuelo_t*)vuelo1);
  size_t prioridad2=vuelo_prioridad((vuelo_t*)vuelo2);

  if (prioridad1<prioridad2) {
    return 1;
  }

  if (prioridad1>prioridad2) {
    return -1;
  }

  return strcmp(vuelo_codigo((vuelo_t*)vuelo1), vuelo_codigo((vuelo_t*)vuelo2));

}



//Indica la cantidad de elementos que tiene el
//arreglo de cadenas que forma el comando.
//No toma en cuenta el elemento NULL
size_t cantidad_elementos(const char** arr_cadenas){

  size_t cantidad=0;

  size_t i=0;

  while (arr_cadenas[i]!=NULL) {
    cantidad++;
    i++;
  }

  return cantidad;

}



int es_fecha_valida(char* fecha){

  char** dia_y_hora=split(fecha, SEPARADOR_DIA_HORA);

  if (!dia_y_hora) {
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  if (cantidad_elementos((const char**)dia_y_hora)!=2) {
    free_strv(dia_y_hora);
    return FECHA_INVALIDA;
  }

  char** dia=split(dia_y_hora[0], SEPARADOR_DIA);

  if (!dia) {
    free_strv(dia_y_hora);
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  if (cantidad_elementos((const char**)dia)!=3) {
    free_strv(dia);
    free_strv(dia_y_hora);
    return FECHA_INVALIDA;
  }

  for (size_t i = 0; i < 3; i++) {
    if (!es_un_entero(dia[i])) {
      free_strv(dia);
      free_strv(dia_y_hora);
      return FECHA_INVALIDA;
    }
  }


  char** hora=split(dia_y_hora[1], SEPARADOR_HORA);

  if (!hora) {
    free_strv(dia);
    free_strv(dia_y_hora);
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  if (cantidad_elementos((const char**)dia)!=3) {
    free_strv(dia);
    free_strv(hora);
    free_strv(dia_y_hora);
    return FECHA_INVALIDA;
  }

  for (size_t i = 0; i < 3; i++) {
    if (!es_un_entero(hora[i])) {
      free_strv(dia);
      free_strv(hora);
      free_strv(dia_y_hora);
      return FECHA_INVALIDA;
    }
  }

  free_strv(dia);
  free_strv(hora);
  free_strv(dia_y_hora);

  return FECHA_VALIDA;

}




void destruir_vuelo(void* vuelo){

  vuelo_destruir((vuelo_t*)vuelo);

}


//Desencola todos los elementos del heap y los imprime de menor
//a mayor prioridad
void imprimir_elementos_heap(heap_t* heap){

  if (heap_esta_vacio(heap)) {
    return;
  }

  vuelo_t* vuelo= heap_desencolar(heap);

  imprimir_elementos_heap(heap);

  printf("%lu - %s\n", vuelo_prioridad(vuelo), vuelo_codigo(vuelo));
}



bool imprimir_codigo_y_fecha(void* dato, void* extra){

  if (!contador_aumentar((contador_t*)extra)) {
    return false;
  }

  const char** informacion_vuelo=vuelo_obtener_informacion((vuelo_t*)dato);

  printf("%s - %s\n", informacion_vuelo[6], informacion_vuelo[0]);

  return true;

}

bool guardar_vuelo(void* dato, void* extra){

    lista_e_indicador_t* copia_extra=(lista_e_indicador_t*)extra;

  if (!lista_insertar_ultimo(copia_extra->lista, dato)) {
    copia_extra->indicador=false;
    return false;
  }

  return true;

}


int agregar_archivo(hash_t* hash, abb_t* abb, char** elementos_comando){

  FILE* vuelos = fopen (elementos_comando[1],"r");

  if (!vuelos){
    return NO_SE_PUDO_ABRIR_EL_ARCHIVO;
  }

  vuelo_t* vuelo;

  hash_iter_t* iter_hash=hash_iter_crear(hash);

  while (!hash_iter_al_final(iter_hash)) {
    vuelo=hash_obtener(hash, hash_iter_ver_actual(iter_hash));
    abb_borrar(abb, vuelo_fecha(vuelo), vuelo_codigo(vuelo));
    hash_iter_avanzar(iter_hash);
  }

  hash_iter_destruir(iter_hash);


  char* informacion_vuelo=NULL;
  size_t tamanio;
  size_t largo=getline(&informacion_vuelo, &tamanio, vuelos);


  while (largo!=-1) {
    informacion_vuelo[largo-1]='\0';
    vuelo=vuelo_crear(informacion_vuelo, SEPARADOR_DATOS_VUELOS);

    if (!vuelo) {
      free(informacion_vuelo);
      fclose(vuelos);
      return ERROR_CON_MEMORIA_DINAMICA;
    }

    if (!hash_guardar(hash, vuelo_codigo(vuelo), vuelo)) {
      vuelo_destruir(vuelo);
      free(informacion_vuelo);
      fclose(vuelos);
      return ERROR_CON_MEMORIA_DINAMICA;
    }

    free(informacion_vuelo);

    informacion_vuelo=NULL;
    largo=getline(&informacion_vuelo, &tamanio, vuelos);

  }

  free(informacion_vuelo);
  fclose(vuelos);

  iter_hash=hash_iter_crear(hash);

  while (!hash_iter_al_final(iter_hash)) {
    vuelo=hash_obtener(hash, hash_iter_ver_actual(iter_hash));
    if (!abb_guardar(abb, vuelo_fecha(vuelo), vuelo_codigo(vuelo), vuelo)) {
      hash_iter_destruir(iter_hash);
      free(informacion_vuelo);
      return ERROR_CON_MEMORIA_DINAMICA;
    }
    hash_iter_avanzar(iter_hash);
  }

  hash_iter_destruir(iter_hash);

  return PROCESO_REALIZADO_CON_EXITO;

}



int ver_tablero(hash_t* hash, abb_t* abb, char** elementos_comando){

  contador_t* vuelos_a_mostrar=contador_crear(obtener_entero(elementos_comando[1]));

  if (!vuelos_a_mostrar) {
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  abb_in_order(abb, imprimir_codigo_y_fecha, vuelos_a_mostrar, elementos_comando[3], elementos_comando[4], elementos_comando[2]);

  contador_destruir(vuelos_a_mostrar);

  return PROCESO_REALIZADO_CON_EXITO;

}


int info_vuelo(hash_t* hash, abb_t* abb, char** elementos_comando){

  vuelo_t* vuelo= hash_obtener(hash, elementos_comando[1]);

  if (!vuelo) {
    return VUELO_INEXISTENTE;
  }

  const char** informacion_vuelo=vuelo_obtener_informacion(vuelo);

  imprimir_arreglo_de_cadenas(informacion_vuelo);

  return PROCESO_REALIZADO_CON_EXITO;

}


int prioridad_vuelos(hash_t* hash, abb_t* abb, char** elementos_comando){

  heap_t* vuelos_por_prioridad=heap_crear(mayor_prioridad_inversa);

  if (!vuelos_por_prioridad) {
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  int vuelos_a_mostrar=obtener_entero(elementos_comando[1]);

  hash_iter_t* iter_hash=hash_iter_crear(hash);

  if (!iter_hash) {
    heap_destruir(vuelos_por_prioridad, NULL);
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  vuelo_t* actual;


  while (!hash_iter_al_final(iter_hash)) {

    actual=hash_obtener(hash, hash_iter_ver_actual(iter_hash));

    if (!heap_encolar(vuelos_por_prioridad, actual)) {
      hash_iter_destruir(iter_hash);
      heap_destruir(vuelos_por_prioridad, NULL);
      return ERROR_CON_MEMORIA_DINAMICA;
    }

    if (heap_cantidad(vuelos_por_prioridad)>vuelos_a_mostrar) {
      heap_desencolar(vuelos_por_prioridad);
    }

    hash_iter_avanzar(iter_hash);
  }

  hash_iter_destruir(iter_hash);

  imprimir_elementos_heap(vuelos_por_prioridad);

  heap_destruir(vuelos_por_prioridad, NULL);

  return PROCESO_REALIZADO_CON_EXITO;

}

int borrar(hash_t* hash, abb_t* abb, char** elementos_comando){

  lista_t* vuelos_a_borrar=lista_crear();

  if (!vuelos_a_borrar) {
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  lista_e_indicador_t extra;

  extra.lista=vuelos_a_borrar;
  extra.indicador=true;

  abb_in_order(abb, guardar_vuelo, &extra, elementos_comando[1], elementos_comando[2], ORDEN_ASCENDENTE);

  if (!extra.indicador) {
    lista_destruir(vuelos_a_borrar, NULL);
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  vuelo_t* actual;

  while (!lista_esta_vacia(vuelos_a_borrar)) {
    actual=lista_borrar_primero(vuelos_a_borrar);
    hash_borrar(hash, vuelo_codigo(actual));
    abb_borrar(abb, vuelo_fecha(actual), vuelo_codigo(actual));
    imprimir_arreglo_de_cadenas(vuelo_obtener_informacion(actual));
    vuelo_destruir(actual);
  }

  lista_destruir(vuelos_a_borrar, NULL);

  return PROCESO_REALIZADO_CON_EXITO;

}

comando_t obtener_comando_a_ejecutar(char** componentes_comando){

  size_t cantidad_de_elementos=cantidad_elementos((const char**)componentes_comando);


  if (!strcmp(componentes_comando[0], AGREGAR_ARCHIVO)) {
    if (cantidad_de_elementos!=2) {
      return NULL;
    }
    return agregar_archivo;
  }else if(!strcmp(componentes_comando[0], VER_TABLERO)){
    if (cantidad_de_elementos!=5) {
      return NULL;
    }
    if ((!es_un_entero(componentes_comando[1]))||(obtener_entero(componentes_comando[1])<0)) {
      return NULL;
    }
    if ((!es_fecha_valida(componentes_comando[3]))||(!es_fecha_valida(componentes_comando[4]))) {
      return NULL;
    }
    if ((strcmp(componentes_comando[2], ORDEN_ASCENDENTE))&&(strcmp(componentes_comando[2], ORDEN_DESCENDENTE))) {
      return NULL;
    }
    if (strcmp(componentes_comando[3], componentes_comando[4])>0) {
      return NULL;
    }
    return ver_tablero;
  }else if(!strcmp(componentes_comando[0], INFO_VUELO)){
    if (cantidad_de_elementos!=2) {
      return NULL;
    }
    return info_vuelo;
  }else if(!strcmp(componentes_comando[0], PRIORIDAD_VUELOS)){
    if (cantidad_de_elementos!=2) {
      return NULL;
    }
    if ((!es_un_entero(componentes_comando[1]))||(obtener_entero(componentes_comando[1])<0)) {
      return NULL;
    }
    return prioridad_vuelos;
  }else if(!strcmp(componentes_comando[0], BORRAR)){
    if (cantidad_de_elementos!=3) {
      return NULL;
    }
    if ((!es_fecha_valida(componentes_comando[1]))||(!es_fecha_valida(componentes_comando[2]))) {
      return NULL;
    }
    if (strcmp(componentes_comando[1], componentes_comando[2])>0) {
      return NULL;
    }
    return borrar;
  }

  return NULL;

}



int procesar_comando(hash_t* hash, abb_t* abb){

  int estado_de_ejecucion=PROCESO_REALIZADO_CON_EXITO;

  char* comando=NULL;
  size_t tamanio;

  size_t largo=getline(&comando, &tamanio, stdin);

  if (largo==-1) {
    free(comando);
    return SE_ACABO_EL_ARCHIVO;
  }

  comando[largo-1]='\0';

  char** componentes_comando=split(comando, SEPARADOR_ENTRADA_ESTANDAR);

  free(comando);
  comando=NULL;

  if (!componentes_comando) {
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  comando_t comando_a_ejecutar=obtener_comando_a_ejecutar(componentes_comando);


  if (!comando_a_ejecutar) {
    fprintf(stderr, "Error en comando %s\n", componentes_comando[0]);
    free_strv(componentes_comando);
    return COMANDO_INVALIDO;
  }

  estado_de_ejecucion=comando_a_ejecutar(hash, abb, componentes_comando);

  if (estado_de_ejecucion!=PROCESO_REALIZADO_CON_EXITO) {
    fprintf(stderr, "Error en comando %s\n", componentes_comando[0]);
    free_strv(componentes_comando);
    return COMANDO_INVALIDO;
  }

  free_strv(componentes_comando);

  printf("OK\n");

  return estado_de_ejecucion;

}


int main(int argc, char const *argv[]) {

  int estado_de_ejecucion;

  hash_t* hash_vuelos=hash_crear(destruir_vuelo);

  if (!hash_vuelos) {
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  abb_t* abb_vuelos=abb_crear(strcmp, strcmp, NULL);

  if (!abb_vuelos) {
    hash_destruir(hash_vuelos);
    return ERROR_CON_MEMORIA_DINAMICA;
  }

  do {

    estado_de_ejecucion=procesar_comando(hash_vuelos, abb_vuelos);

  } while(estado_de_ejecucion!=SE_ACABO_EL_ARCHIVO);


  hash_destruir(hash_vuelos);
  abb_destruir(abb_vuelos);

  return 0;

}
