#define _POSIX_C_SOURCE 200809L
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "hash.h"
#include "lista.h"

#define LARGO_INICIAL 11
#define FACTOR_DE_REDIMENSION_AGRANDAR 3
#define FACTOR_DE_REDIMENSION_ACHICAR 1


typedef void (*hash_destruir_dato_t)(void *);

typedef struct hash_campo {
    char *clave;
    void *valor;
}hash_campo_t;



struct hash {
    size_t cantidad;
    size_t largo;
    size_t carga;
    lista_t** tabla;
    hash_destruir_dato_t destruir_dato;
};


struct hash_iter{
  const hash_t* hash;
  lista_iter_t* lista_iter;
  size_t posicion;
};



//fuente: https://en.wikipedia.org/wiki/Rabin%E2%80%93Karp_algorithm
int _hashing(char* cadena, int valor_acumulado, int caracter_a_calcular){

  //cantidad de caracteres de la tabla de ascii
  //pasar a constante
  int base=256;

  //pasar a constante
  int primo=101;

  if (cadena[caracter_a_calcular]=='\0') {
    return valor_acumulado;
  }

  return _hashing(cadena, (valor_acumulado*base+cadena[caracter_a_calcular])%primo, caracter_a_calcular+1);

}

int hashing(char* cadena){

  return _hashing(cadena, 0, 0);

}


bool es_primo(size_t numero){

  for (size_t i = 2; i < numero; i++) {
    if (numero%i==0) {
      return false;
    }
  }

  return true;

}


//Devuelve el primo más cercano al número
//pasado que sea mayor que este
size_t proximo_primo(size_t numero){

  size_t actual= numero+1;

  while (!es_primo(actual)) {
    actual++;
  }

  return actual;

}



//Devuelve el primo más cercano al número
//pasado que sea menor que este
size_t primo_anterior(size_t numero){

  size_t actual=numero-1;

  while ((!es_primo(actual))&&(actual>1)) {
    actual--;
  }

  return actual;

}


bool redimensionar_hash(hash_t* hash, size_t tamanio_nuevo){

  hash_t* nuevo_hash=hash_crear(hash->destruir_dato);

  if (!nuevo_hash) {
    return false;
  }

  hash_iter_t* hash_iter=hash_iter_crear(hash);

  if (!hash_iter) {
    hash_destruir(nuevo_hash);
    return false;
  }

  char* clave_auxiliar;

  while (!hash_iter_al_final(hash_iter)) {
    clave_auxiliar=strdup(hash_iter_ver_actual(hash_iter));
    if (!clave_auxiliar) {
      hash_iter_destruir(hash_iter);
      hash_destruir(nuevo_hash);
      return false;
    }

    if (!hash_guardar(nuevo_hash, clave_auxiliar, hash_obtener(hash, clave_auxiliar))) {
      hash_iter_destruir(hash_iter);
      hash_destruir(nuevo_hash);
      return false;
    }
    hash_iter_avanzar(hash_iter);
  }

  hash_iter_destruir(hash_iter);
  hash_destruir(hash);
  hash=nuevo_hash;

  return true;

}

//libera la memoria tomada por el campo
//y devuelve el dato almacenado
void* destruir_campo(hash_campo_t* campo){
  void* dato=campo->valor;
  free(campo->clave);
  free(campo);
  return dato;
}

void destruir_lista_de_campos(lista_t* lista, hash_destruir_dato_t destruir_dato){
  while (!lista_esta_vacia(lista)) {
    destruir_dato(destruir_campo(lista_borrar_primero(lista)));
  }
  lista_destruir(lista, NULL);
}


int hash_buscar_primera_lista(const hash_t* hash, lista_t** lista){

  size_t largo_hash=hash->largo;

  for (size_t i = 0; i < largo_hash; i++) {
    if (hash->tabla[i]!=NULL) {
      *lista=hash->tabla[i];
      return i;
    }
  }

  return -1;

}




//indica si la clave pasada está almacenada
//en alguno de los hash_campos de la lista


//BORRAR Y USAR buscar_en_la_lista Y CHEQUEAR SI DEVUELVE NULL
bool esta_en_la_lista(lista_t* lista, const char* clave){

  lista_iter_t* iter=lista_iter_crear(lista);

  if (!iter) {
    return false;
  }

  size_t largo_lista=lista_largo(lista);

  hash_campo_t* actual;

  for (size_t i = 0; i < largo_lista; i++) {
    actual=lista_iter_ver_actual(iter);
    if (!strcmp(actual->clave,clave)) {
      return true;
    }
  }

  return false;

}


hash_campo_t* buscar_en_la_lista(lista_t* lista,const char* clave){

  lista_iter_t* iter=lista_iter_crear(lista);

  if (!iter) {
    return NULL;
  }

  size_t largo_lista=lista_largo(lista);

  hash_campo_t* actual;

  for (size_t i = 0; i < largo_lista; i++) {
    actual=lista_iter_ver_actual(iter);
    if (!strcmp(actual->clave,clave)) {
      return actual;
    }
  }

  return NULL;

}


/* Crea el hash
 */
hash_t *hash_crear(hash_destruir_dato_t destruir_dato){

  hash_t* hash=malloc(sizeof(hash_t));

  if (!hash) {
    return NULL;
  }

  hash->tabla= malloc(sizeof(lista_t*)*LARGO_INICIAL);

  if (!hash->tabla) {
    free(hash);
    return NULL;
  }



  hash->largo=LARGO_INICIAL;
  hash->cantidad=0;
  hash->carga=0;
  hash->destruir_dato=destruir_dato;

  for (size_t i = 0; i < hash->largo; i++) {
    hash->tabla[i]=NULL;
  }

  return hash;
}

/* Guarda un elemento en el hash, si la clave ya se encuentra en la
 * estructura, la reemplaza. De no poder guardarlo devuelve false.
 * Pre: La estructura hash fue inicializada
 * Post: Se almacenó el par (clave, dato)
 */
bool hash_guardar(hash_t *hash, const char *clave, void *dato){

  if (hash->cantidad/hash->largo>FACTOR_DE_REDIMENSION_AGRANDAR) {
    if (!redimensionar_hash(hash, proximo_primo(hash->largo))) {
      return false;
    }
  }


  hash_campo_t* campo=malloc(sizeof(hash_campo_t));

  if (!campo) {
    return false;
  }


  campo->clave=strdup(clave);

  if (!campo->clave) {
    free(campo);
    return false;
  }

  campo->valor=dato;

  size_t posicion_elemento=0;

  if (hash->largo!=0) {
    posicion_elemento=hashing((char*)clave)%hash->largo;
  }


  if (!hash->tabla[posicion_elemento]) {
    hash->tabla[posicion_elemento]=lista_crear();
    if (!hash->tabla[posicion_elemento]) {
      destruir_campo(campo);
      return false;
    }
  }


  //pasar a funcion a parte?
  hash_campo_t* ya_guardado=buscar_en_la_lista(hash->tabla[posicion_elemento], clave);
  if (!ya_guardado) {
    if (!lista_insertar_ultimo(hash->tabla[posicion_elemento], campo)) {
      destruir_campo(campo);
      return false;
    }
    hash->cantidad++;
  }else{
    hash->destruir_dato(ya_guardado->valor);
    ya_guardado->valor=dato;
  }


  return true;

}

/* Borra un elemento del hash y devuelve el dato asociado.  Devuelve
 * NULL si el dato no estaba.
 * Pre: La estructura hash fue inicializada
 * Post: El elemento fue borrado de la estructura y se lo devolvió,
 * en el caso de que estuviera guardado.
 */
void *hash_borrar(hash_t *hash, const char *clave){

  size_t posicion_elemento=hashing((char*)clave)%hash->largo;
  void* valor_a_retornar;
  if(!hash_pertenece(hash, clave)){
    return NULL;
  }
  valor_a_retornar = destruir_campo(buscar_en_la_lista(hash->tabla[posicion_elemento], clave));
  //hash->destruir_dato(hash->tabla[posicion_elemento]);
  hash->cantidad--;
  /*
   NO ESTOY MUY SEGURA DE ESTO, PERO SE ME OCURRIO ALGO ASI
   PORQUE COMO NO PODEMOS USAR EL ITERADOR Y YA TE PASABAN
   LA FUNCION DE DESTRUIR EL DATO TAL VEZ SE PODIA HACER ESTO,
   sino decime y veo otra forma :) */
  if ((hash->largo>LARGO_INICIAL)&&(hash->cantidad/hash->largo<FACTOR_DE_REDIMENSION_ACHICAR)) {
    size_t tamanio_nuevo=primo_anterior(hash->largo);

    if (tamanio_nuevo>=LARGO_INICIAL) {
      redimensionar_hash(hash, tamanio_nuevo);
    }

  }

  return valor_a_retornar;

}

/* Obtiene el valor de un elemento del hash, si la clave no se encuentra
 * devuelve NULL.
 * Pre: La estructura hash fue inicializada
 */
void *hash_obtener(const hash_t *hash, const char *clave){

  size_t posicion_elemento=hashing((char*)clave)%hash->largo;

  /*
  if(hash_pertenece(hash, clave)){
    return hash->tabla[posicion_elemento];
  }else{
    return NULL;
  }
  */

  if (!hash->tabla[posicion_elemento]) {
    return NULL;
  }

  return buscar_en_la_lista(hash->tabla[posicion_elemento], clave)->valor;

}

/* Determina si clave pertenece o no)*hash_tLARGOhash.
 * Pre: La estructura hash fue inicializada
 */
bool hash_pertenece(const hash_t *hash, const char *clave){

  size_t posicion_elemento;
  posicion_elemento=hashing((char*)clave)%hash->largo;

  if(hash->tabla[posicion_elemento]==NULL){
    return false;
  }

  return esta_en_la_lista(hash->tabla[posicion_elemento], clave);

}

/* Devuelve la cantidad de elementos del hash.
 * Pre: La estructura hash fue inicializada
 */
size_t hash_cantidad(const hash_t *hash){

  return hash->cantidad;

}

/* Destruye la estructura liberando la memoria pedida y llamando a la función
 * destruir para cada par (clave, dato).
 * Pre: La estructura hash fue inicializada
 * Post: La estructura hash fue destruida
 */
void hash_destruir(hash_t *hash){
  /*
  void* dato;
  while(!lista_esta_vacia(*hash->tabla)){
    dato=lista_borrar_primero(*hash->tabla);
    if(hash->destruir_dato!=NULL){
      hash->destruir_dato(dato);
    }
    free(*hash->tabla);
  }
  free(hash);
  */
  size_t largo_hash=hash->largo;

  for (size_t i = 0; i < largo_hash; i++) {
    if (hash->tabla[i]!=NULL) {
      //lista_destruir(hash->tabla[i], destruir_campo);
      destruir_lista_de_campos(hash->tabla[i],hash->destruir_dato);
    }
  }

  free(hash->tabla);
  free(hash);

}

/* Iterador del hash */

// Crea iterador
hash_iter_t *hash_iter_crear(const hash_t *hash){

  hash_iter_t* iter = malloc(sizeof(hash_iter_t));

  if(!iter){
    return NULL;
  }

  iter->hash = hash;

  int indice_primera_lista=0;

  if (hash->cantidad==0) {
    iter->lista_iter=NULL;
    iter->posicion=0;
    return iter;
  }else{
    lista_t* primera_lista;
    indice_primera_lista=hash_buscar_primera_lista(hash, &primera_lista);
    iter->lista_iter = lista_iter_crear(primera_lista);
  }

  if (!iter->lista_iter) {
    free(iter);
    return NULL;
  }

  iter->posicion=indice_primera_lista;

  return iter;

}




// Avanza iterador
bool hash_iter_avanzar(hash_iter_t *iter){

  //bool avanzo=true;

  /*

  //la verdad no entiendo nada de lo que esta escrito aca xd
  while(lista_iter_al_final(iter->lista_iter)){
    iter->posicion++;
  }
  if(!lista_iter_al_final(iter->lista_iter)){
    avanzo=lista_iter_avanzar(iter->lista_iter);
  }
  */




  //hay que agregar el caso en el que el proximo elemento es NULL
  //(cuando esta al final de la lista) porque se tiene que pasar a la
  //lista siguiente

  //el iterador de la lista devuelve false para avanzar si actual esta en
  //NULL asuque habría un caso en el que se devuelve NULL, hay que verificar que
  //después de avanzar no se está al final de la lista, sino hay que pasar a la
  //lista siguiente

  if (hash_iter_al_final(iter)) {
    return false;
  }

  if (!lista_iter_avanzar(iter->lista_iter)) {
    lista_iter_destruir(iter->lista_iter);
    iter->posicion++;

    while (!iter->hash->tabla[iter->posicion]) {
      if (iter->posicion > iter->hash->largo) {
        return false;
      }
      iter->posicion++;
    }

    iter->lista_iter=lista_iter_crear(iter->hash->tabla[iter->posicion]);

    if (!iter->lista_iter) {
      return false;
    }

  }

  //return avanzo;
  return true;

}



// Devuelve clave actual, esa clave no se puede modificar ni liberar.
const char *hash_iter_ver_actual(const hash_iter_t *iter){

  if (hash_iter_al_final(iter)) {
    return NULL;
  }

  /*
  char* clave_actual=((hash_campo_t*)lista_iter_ver_actual(iter->lista_iter))->clave;
  char* clave_a_retornar="";
  strcpy(clave_a_retornar, clave_actual);


  return clave_a_retornar;
  */

  return (const char*)(((hash_campo_t*)lista_iter_ver_actual(iter->lista_iter))->clave);

}


// Comprueba si terminó la iteración
bool hash_iter_al_final(const hash_iter_t *iter){

  if (!iter->lista_iter) {
    return true;
  }

  return (iter->posicion==iter->hash->largo-1)&&(lista_iter_al_final(iter->lista_iter));

}


// Destruye iterador
void hash_iter_destruir(hash_iter_t* iter){

  lista_iter_destruir(iter->lista_iter);
  free(iter);

}
