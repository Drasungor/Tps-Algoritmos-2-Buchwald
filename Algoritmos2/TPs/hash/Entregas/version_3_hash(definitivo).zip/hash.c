//Entrega 1 hash
//Grupo:G21
//Integrantes: Cambiano Agustín - Gualdieri Sofía
//Correctora: Dvorkin Camila


#define _POSIX_C_SOURCE 200809L
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include <stdio.h>

#include "hash.h"
#include "lista.h"

#define LARGO_INICIAL 59
#define FACTOR_DE_REDIMENSION_AGRANDAR 3
#define FACTOR_DE_REDIMENSION_ACHICAR 1


typedef void (*hash_destruir_dato_t)(void *);

typedef struct hash_campo {
    char *clave;
    void *valor;
}hash_campo_t;



struct hash {
    size_t cantidad;
    size_t largo;
    lista_t** tabla;
    hash_destruir_dato_t destruir_dato;
};


struct hash_iter{
  const hash_t* hash;
  lista_iter_t* lista_iter;
  size_t posicion;
};



//Fuente: https://codereview.stackexchange.com/questions/85556/simple-string-hashing-algorithm-implementation
size_t hashing(const char* cp)
{
    size_t hash = 0x811c9dc5;
    while (*cp) {
        hash ^= (unsigned char) *cp++;
        hash *= 0x01000193;
    }
    return hash;
}


//libera la memoria tomada por el campo
//y devuelve el dato almacenado
void* destruir_campo(hash_campo_t* campo){
  void* dato=campo->valor;
  free(campo->clave);
  free(campo);
  return dato;
}


//Destruye la lista y todos los campos de esta
void destruir_lista_de_campos(lista_t* lista, hash_destruir_dato_t destruir_dato){

  void* dato;

  while (!lista_esta_vacia(lista)) {

    dato=destruir_campo(lista_borrar_primero(lista));

    if (destruir_dato!=NULL) {
      destruir_dato(dato);
    }

  }
  lista_destruir(lista, NULL);
}


//Crea un vector de listas del largo pasado por parametro
lista_t** crear_tabla(size_t largo){

  lista_t** tabla=malloc(sizeof(lista_t*)*largo);

  for (size_t i = 0; i < largo; i++) {

    tabla[i]=lista_crear();

    if (!tabla[i]) {
      for (size_t j = 0; j < i; j++) {
        destruir_lista_de_campos(tabla[j], NULL);
      }
      return NULL;
    }

  }

  return tabla;

}




bool redimensionar_hash(hash_t* hash, size_t tamanio_nuevo){

  lista_t** nueva_tabla=crear_tabla(tamanio_nuevo);

  if (!nueva_tabla) {
    hash_destruir(hash);
    return false;
  }

  size_t largo_hash=hash->largo;
  hash_campo_t* actual;

  for (size_t i = 0; i < largo_hash; i++) {
    while (!lista_esta_vacia(hash->tabla[i])) {
      actual=lista_borrar_primero(hash->tabla[i]);

      if (!lista_insertar_ultimo(nueva_tabla[hashing(actual->clave)%tamanio_nuevo], actual)) {
        for (size_t j = 0; j < tamanio_nuevo; j++) {
            destruir_lista_de_campos(nueva_tabla[j], hash->destruir_dato);
        }
        free(nueva_tabla);
        hash_destruir(hash);
        return false;
      }

    }
  }

  for (size_t i = 0; i < largo_hash; i++) {
    lista_destruir(hash->tabla[i], NULL);
  }
  free(hash->tabla);
  hash->tabla=nueva_tabla;
  hash->largo=tamanio_nuevo;

  return true;

}


//Crea un campo con la clave y dato pasados
hash_campo_t* crear_campo(const char* clave, void* dato){

  hash_campo_t* campo=malloc(sizeof(hash_campo_t));

  if (!campo) {
    return NULL;
  }

  campo->clave=strdup(clave);

  if (!clave) {
    free(campo);
    return NULL;
  }

  campo->valor=dato;

  return campo;

}






//Busca la primera lista no vacia del hash
int hash_buscar_primera_lista(const hash_t* hash, lista_t** lista){

  size_t largo_hash=hash->largo;

  for (int i = 0; i < largo_hash; i++) {
    if (!lista_esta_vacia(hash->tabla[i])/*hash->tabla[i]!=NULL*/) {
      *lista=hash->tabla[i];
      return i;
    }
  }

  return -1;

}


//Busca el elemento con la clave pasada en la lista proporcionada
hash_campo_t* buscar_en_la_lista(lista_t* lista,const char* clave){

  lista_iter_t* iter=lista_iter_crear(lista);

  if (!iter) {
    return NULL;
  }

  size_t largo_lista=lista_largo(lista);

  hash_campo_t* actual;

  for (size_t i = 0; i < largo_lista; i++) {
    actual=lista_iter_ver_actual(iter);
    if (!strcmp(actual->clave,clave)) {
      lista_iter_destruir(iter);
      return actual;
    }
    lista_iter_avanzar(iter);
  }

  lista_iter_destruir(iter);

  return NULL;

}


//Borra de la lista el elemento con la clave proporcionada
hash_campo_t* borrar_de_la_lista(lista_t* lista,const char* clave){


    lista_iter_t* iter=lista_iter_crear(lista);

    if (!iter) {
      return NULL;
    }

    hash_campo_t* campo;

    size_t largo_lista=lista_largo(lista);


    for (size_t i = 0; i < largo_lista; i++) {
      campo=lista_iter_ver_actual(iter);
      if (!strcmp(campo->clave,clave)) {
        campo=lista_iter_borrar(iter);
        lista_iter_destruir(iter);
        return campo;
      }
      lista_iter_avanzar(iter);
    }

    lista_iter_destruir(iter);

    return NULL;


}


/* Crea el hash
 */
hash_t *hash_crear(hash_destruir_dato_t destruir_dato){

  hash_t* hash=malloc(sizeof(hash_t));

  if (!hash) {
    return NULL;
  }

  hash->tabla= crear_tabla(LARGO_INICIAL);

  if (!hash->tabla) {
    free(hash);
    return NULL;
  }



  hash->largo=LARGO_INICIAL;
  hash->cantidad=0;
  hash->destruir_dato=destruir_dato;

  return hash;
}




/* Guarda un elemento en el hash, si la clave ya se encuentra en la
 * estructura, la reemplaza. De no poder guardarlo devuelve false.
 * Pre: La estructura hash fue inicializada
 * Post: Se almacenó el par (clave, dato)
 */
bool hash_guardar(hash_t *hash, const char *clave, void *dato){

  if (hash->cantidad/hash->largo>FACTOR_DE_REDIMENSION_AGRANDAR) {
    if (!redimensionar_hash(hash, hash->cantidad/*proximo_primo(hash->largo)*/)) {
      return false;
    }
  }


  size_t posicion_elemento=0;

  if (hash->largo!=0) {
    posicion_elemento=hashing((char*)clave)%hash->largo;
  }


  if (!hash_pertenece(hash, clave)) {
    hash_campo_t* campo=crear_campo(clave, dato);

    if (!campo) {
      return NULL;
    }

    if (!lista_insertar_ultimo(hash->tabla[posicion_elemento], campo)) {
      destruir_campo(campo);
      return false;
    }
    hash->cantidad++;
  }else{
    hash_campo_t* ya_guardado=buscar_en_la_lista(hash->tabla[posicion_elemento], clave);

    if (hash->destruir_dato!=NULL) {
      hash->destruir_dato(ya_guardado->valor);
    }
    ya_guardado->valor=dato;

  }

  return true;

}

/* Borra un elemento del hash y devuelve el dato asociado.  Devuelve
 * NULL si el dato no estaba.
 * Pre: La estructura hash fue inicializada
 * Post: El elemento fue borrado de la estructura y se lo devolvió,
 * en el caso de que estuviera guardado.
 */
void *hash_borrar(hash_t *hash, const char *clave){

  size_t posicion_elemento=hashing((char*)clave)%hash->largo;
  void* valor_a_retornar;


  //borrar el hash_pertenece y cambiarlo por el buscar en la lista porque
  //el hash_pertenece usa buscar_en_la_lista y se esta usando innecesariamente
  //dos veces la misma funcion
  if(!hash_pertenece(hash, clave)){
    return NULL;
  }
  valor_a_retornar = destruir_campo(borrar_de_la_lista(hash->tabla[posicion_elemento], clave));
  hash->cantidad--;

  if ((hash->largo>LARGO_INICIAL)&&(hash->cantidad/hash->largo<FACTOR_DE_REDIMENSION_ACHICAR)) {
    size_t tamanio_nuevo=hash->cantidad/2/*primo_anterior(hash->largo)*/;

    if (tamanio_nuevo>=LARGO_INICIAL) {
      redimensionar_hash(hash, tamanio_nuevo);
    }

  }

  return valor_a_retornar;

}

/* Obtiene el valor de un elemento del hash, si la clave no se encuentra
 * devuelve NULL.
 * Pre: La estructura hash fue inicializada
 */
void *hash_obtener(const hash_t *hash, const char *clave){

  size_t posicion_elemento=hashing((char*)clave)%hash->largo;

  if (!hash->tabla[posicion_elemento]) {
    return NULL;
  }

  hash_campo_t* campo=buscar_en_la_lista(hash->tabla[posicion_elemento], clave);

  if (!campo) {
    return NULL;
  }

  return campo->valor;

}

/* Determina si clave pertenece o no)*hash_tLARGOhash.
 * Pre: La estructura hash fue inicializada
 */
bool hash_pertenece(const hash_t *hash, const char *clave){

  size_t posicion_elemento;
  posicion_elemento=hashing((char*)clave)%hash->largo;

  if(hash->tabla[posicion_elemento]==NULL){
    return false;
  }

  return buscar_en_la_lista(hash->tabla[posicion_elemento], clave)!=NULL;

}

/* Devuelve la cantidad de elementos del hash.
 * Pre: La estructura hash fue inicializada
 */
size_t hash_cantidad(const hash_t *hash){

  return hash->cantidad;

}

/* Destruye la estructura liberando la memoria pedida y llamando a la función
 * destruir para cada par (clave, dato).
 * Pre: La estructura hash fue inicializada
 * Post: La estructura hash fue destruida
 */
void hash_destruir(hash_t *hash){

  size_t largo_hash=hash->largo;

  for (size_t i = 0; i < largo_hash; i++) {
    destruir_lista_de_campos(hash->tabla[i], hash->destruir_dato);
  }

  free(hash->tabla);
  free(hash);

}



/* Iterador del hash */

// Crea iterador
hash_iter_t *hash_iter_crear(const hash_t *hash){

  hash_iter_t* iter = malloc(sizeof(hash_iter_t));

  if(!iter){
    return NULL;
  }

  iter->hash = hash;

  int indice_primera_lista=0;

  if (hash->cantidad==0) {
    iter->lista_iter=NULL;
    iter->posicion=0;
    return iter;
  }else{
    lista_t* primera_lista;
    indice_primera_lista=hash_buscar_primera_lista(hash, &primera_lista);
    iter->lista_iter = lista_iter_crear(primera_lista);
  }

  if (!iter->lista_iter) {
    free(iter);
    return NULL;
  }

  iter->posicion=indice_primera_lista;

  return iter;

}





// Avanza iterador
bool hash_iter_avanzar(hash_iter_t *iter){

  if (hash_iter_al_final(iter)) {
    return false;
  }

  if ((!lista_iter_avanzar(iter->lista_iter))||(lista_iter_al_final(iter->lista_iter))) {

    if (hash_iter_al_final(iter)) {
      return false;
    }

    lista_iter_destruir(iter->lista_iter);

    iter->posicion++;
    iter->lista_iter=lista_iter_crear(iter->hash->tabla[iter->posicion]);

    if (!iter->lista_iter) {
      return false;
    }

    while (lista_iter_al_final(iter->lista_iter)) {
      if (hash_iter_al_final(iter)) {
        return false;
      }
      lista_iter_destruir(iter->lista_iter);
      iter->posicion++;
      iter->lista_iter=lista_iter_crear(iter->hash->tabla[iter->posicion]);
      if (!iter->lista_iter) {
        return false;
      }
    }

  }

  return true;

}



// Devuelve clave actual, esa clave no se puede modificar ni liberar.
const char *hash_iter_ver_actual(const hash_iter_t *iter){


  if (hash_iter_al_final(iter)) {
    return NULL;
  }

  hash_campo_t* actual=lista_iter_ver_actual(iter->lista_iter);

  return actual->clave;

}


// Comprueba si terminó la iteración
bool hash_iter_al_final(const hash_iter_t *iter){

  if (!iter->lista_iter) {
    return true;
  }

  return (iter->posicion==(iter->hash->largo)-1)&&(lista_iter_al_final(iter->lista_iter));

}


// Destruye iterador
void hash_iter_destruir(hash_iter_t* iter){

  lista_iter_destruir(iter->lista_iter);
  free(iter);

}
