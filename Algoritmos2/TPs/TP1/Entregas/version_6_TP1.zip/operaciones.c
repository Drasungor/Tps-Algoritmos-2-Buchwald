#include "operaciones.h"



int obtener_suma(int argumento1, int argumento2){

  return argumento1+argumento2;

}

int obtener_resta(int argumento1, int argumento2){

  return argumento1-argumento2;

}

int obtener_producto(int argumento1, int argumento2){

  return argumento1*argumento2;

}

int obtener_division(int argumento1, int argumento2){

  return argumento1/argumento2;

}

int aplicar_operador_ternario(int primer_numero, int segundo_numero, int indicador){

    if (indicador==0) {
      return primer_numero;
    }

    return segundo_numero;

}


size_t _obtener_raiz(size_t n,size_t inicio ,size_t fin){


  /*
  //Es necesario este caso base?
  if (inicio==fin) {
    return inicio;
  }
  */


  size_t medio=(inicio+fin)/2;

  if ((medio*medio<n)&&((medio+1)*(medio+1)>n)) {
    return medio;
  }
  if (medio*medio<n) {
    return _obtener_raiz(n, medio+1, fin);
  }
  if (medio*medio>n) {
    return _obtener_raiz(n, inicio, medio-1);
  }

  return medio;

}

size_t obtener_raiz(size_t n){

  return _obtener_raiz(n, 0, n);

}



int obtener_potencia(int base, size_t exponente){

  if (exponente==1) {
    return base;
  }

  if (exponente<0) {
    return 0;
  }

  if (exponente==0) {
    return 1;
  }

  int potencia_menor= obtener_potencia(base, exponente/2);

  if (exponente%2==0) {
    return potencia_menor*potencia_menor;
  }

  return base*potencia_menor*potencia_menor;

}

/*
size_t _obtener_logaritmo(size_t base, size_t argumento, size_t inicio,size_t fin){

  size_t medio= (inicio+fin)/2;
  size_t potencia_actual=obtener_potencia(base, medio);

  if ((potencia_actual<argumento)&&(potencia_actual<argumento)) {
    return medio;
  }
  if (potencia_actual<argumento) {
    return _obtener_logaritmo(base, argumento, medio+1, fin);
  }
  if (potencia_actual>argumento) {
    return _obtener_logaritmo(base, argumento, inicio, medio-1);
  }

  return argumento;

}
*/


size_t obtener_logaritmo(size_t base, size_t argumento){

  if (argumento<base) {
    return 0;
  }

  return 1+obtener_logaritmo(base, argumento/base);

}
