#include "pila.h"
#include "testing.h"
#include <stddef.h>
#include<stdio.h>

/* ******************************************************************
 *                   PRUEBAS UNITARIAS ALUMNO
 * *****************************************************************/

void pruebas_pila_vacia(){
  printf("INICIO DE PRUEBAS CON PILA DE TAMANIO 0\n");


  //como se pruebe pila_crear()?
  pila_t* pila1= pila_crear();

  print_test("crear pila vacia", pila_esta_vacia(pila1));
  print_test("ver tope de la pila vacia", !pila_ver_tope(pila1));
  print_test("desapilar tope de la pila vacia", !pila_desapilar(pila1));
  pila_destruir(pila1);
}

void pruebas_pila_con_1_elemento(){
  printf("INICIO DE PRUEBAS CON PILA DE TAMANIO 1\n");

  pila_t* pila2= pila_crear();
  int elemento_a_agregar=5;

  //ver si hay que sacar estas 3 pruebas porque son iguales a las
  //de arriba
  print_test("crear pila vacia", pila_esta_vacia(pila2));
  print_test("ver tope de la pila vacia", !pila_ver_tope(pila2));
  print_test("desapilar tope de la pila vacia", !pila_desapilar(pila2));

  print_test("apilar un elemento", pila_apilar(pila2, &elemento_a_agregar));

  //se asume que el elemento anterior fue apilado correctamente
  print_test("ver si la pila esta vacia teniendo 1 elemento", !pila_esta_vacia(pila2));
  print_test("ver tope de la pila no vacia", pila_ver_tope(pila2)==&elemento_a_agregar);
  print_test("desapilar un elemento", pila_desapilar(pila2)==&elemento_a_agregar);
  print_test("se desapiló el elemento y la pila está vacía", pila_esta_vacia(pila2));
  pila_destruir(pila2);

}

void prueba_pila_con_algunos_elementos(){
  printf("INICIO DE PRUEBAS CON PILA DE ALGUNOS ELEMENTOS\n");

  pila_t* pila3= pila_crear();

  int elementos[10]={7,64,-23,-769,1463,37,469,1,-1,10};
  bool se_apilo_bien=true;
  bool se_desapilo_bien=true;

  //ver si hay que pasar esto a una función
  for (size_t i = 0; i < 10; i++) {
    if (!pila_apilar(pila3, &elementos[i])) {
      se_apilo_bien=false;
      break;
    }
  }
  print_test("apilar elementos", se_apilo_bien);

  print_test("obtener tope de la pila", pila_ver_tope(pila3)==&elementos[9]);


  for (size_t i = 9; i > -1; i--) {
    if (pila_desapilar(pila3)!=&elementos[i]) {
      se_desapilo_bien=false;
      break;
    }
  }
  print_test("desapilar elementos", se_desapilo_bien);

  print_test("la pila esta vacía después de desapilar", pila_esta_vacia(pila3));

  pila_destruir(pila3);

}


void pruebas_pila_alumno() {

/*
    pila_t* ejemplo = NULL;

    print_test("Puntero inicializado a NULL", ejemplo == NULL);
*/

  pruebas_pila_vacia();
  pruebas_pila_con_1_elemento();
  prueba_pila_con_algunos_elementos();
}
