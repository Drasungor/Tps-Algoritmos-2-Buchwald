#!/usr/bin/python3

from grafo import *
from operaciones_grafo import *
import csv
from constant import *
import sys

"""
def distancia(posicion1, posicion2):
    diferencia_latitud=poicion1[0]-poicion2[0]
    diferencia_longitud=poicion2[0]-poicion2[1]

    return sqrt(diferencia_latitud**2+diferencia_longitud**2)
"""

#Devuelve una lista que va desde la raiz del
#arbol obtenido por el recorrido hasta el destino
def reconstruir_camino(padres, aeropuerto_destino):

    camino=[aeropuerto_destino]
    v=padres[aeropuerto_destino]

    while v!= None:
        camino.append(v)
        v=padres[v]

    camino.reverse()

    return camino


def mejor_camino_a_ciudad_arbol(grafo, aeropuerto_salida, aeropuertos_destino):
    padres=recorrido_bfs(grafo, aeropuerto_salida[0])

    caminos=[]

    for aeropuerto_llegada in aeropuertos_destino:
        #hacer chequeo en reconstruir_camino para ver si el destino esta en
        #el arbol obtenido por bfs, porque el orgien siempre va a estar porque
        #se parte de ahi
        posible_camino=reconstruir_camino(padres, aeropuerto_llegada[0])
        caminos.append(posible_camino)


    if len(caminos)==0:
        return CAMINO_IMPOSIBLE


    mejor_camino=caminos[0]
    escalas_mejor_camino=len(mejor_camino)

    for c in caminos:
        escalas_aux=len(c)
        if escalas_aux<escalas_mejor_camino:
            escalas_mejor_camino=escalas_aux
            mejor_camino=c

    return mejor_camino


#Imprime los elementos de la lista separados con
#el separador
def imprimir_lista_separada(lista, separador):

    largo_lista=len(lista)

    for i in range(largo_lista):
        if i!=largo_lista-1:
            print(lista[i], end=separador)
        else:
            print(lista[i])


def listar_operaciones():

    #PASAR TODOS LOS COMANDOS A CONSTANTE
    #operaciones = [CAMINO_MAS, CAMINO_ESCALAS,"nueva_aerolinea","recorrer_mundo_aprox"]
    operaciones = [CAMINO_MAS, CAMINO_ESCALAS, NUEVA_AEROLINEA]

    for elemento in operaciones:
        print (elemento)



def nueva_aerolinea(grafo_por_precio, archivo_salida):

    with open(archivo_salida, "w") as ruta_aerolinea:
        writer=csv.writer(ruta_aerolinea)
        aristas= mst(grafo_por_precio)

        for vuelo in aristas:
            writer.writerow(vuelo)

        return OPERACION_EXITOSA


def camino_escalas(grafo, ciudades, origen, destino):

    padres=[]
    cantidad_escalas = math.inf
    mejor_camino=[]

    """

    for v in ciudades[origen]:

        #ARREGLAR PORQUE NO IMPORTA EL DESTINO EN ESTE CASO
        #DE LA MISMA FORMA QUE EN DIJKSTRA
        for w in ciudades[destino]:
            padres_auxiliar=recorrido_bfs(grafo, v)
            cantidad_escalas_aux=len(padres_auxiliar)
            if cantidad_escalas_aux<cantidad_escalas:
                cantidad_escalas=cantidad_escalas_aux
                padres=padres_auxiliar

    """

    for aeropuerto_salida in ciudades[origen]:
        mejor_camino_actual=mejor_camino_a_ciudad_arbol(grafo, aeropuerto_salida, ciudades[destino])
        cantidad_escalas_aux=len(mejor_camino_actual)
        if cantidad_escalas_aux<cantidad_escalas:
            cantidad_escalas=cantidad_escalas_aux
            mejor_camino=mejor_camino_actual

    imprimir_lista_separada(mejor_camino, SEPARADOR_CIUDADES)

    return OPERACION_EXITOSA


def camino_mas(grafo, ciudades, origen, destino):

    peso_minimo=math.inf
    camino_minimo_aux=None
    camino_minimo=None

    for salida in ciudades[origen]:
        for llegada in ciudades[destino]:
            camino_minimo_aux, peso_aux=dijkstra(grafo, salida[0], llegada[0])
            if camino_minimo_aux==None:
                continue
            if peso_aux<peso_minimo:
                camino_minimo=camino_minimo_aux

    if camino_minimo==None:
        return CAMINO_IMPOSIBLE

    imprimir_lista_separada(camino_minimo, SEPARADOR_CIUDADES)

    return OPERACION_EXITOSA

def procesar_comando(comando, ciudades, aeropuertos_tiempo, aeropuertos_precio):

    #BORRAR
    #print("Comando: ", comando)


    if comando[0]==LISTAR_OPERACIONES:
        listar_operaciones()

    elif comando[0]==CAMINO_ESCALAS:

        if len(comando)!=3:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return camino_escalas(aeropuertos_tiempo, ciudades, comando[1], comando[2])

    elif comando[0]==CAMINO_MAS:


        if len(comando)!=4:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        if comando[2] not in ciudades or comando[3] not in ciudades:
            return PARAMETROS_INCORRECTOS



        if comando[1]==BARATO:
            return camino_mas(aeropuertos_precio, ciudades, comando[2], comando[3])
        elif comando[1]==RAPIDO:
            return camino_mas(aeropuertos_tiempo, ciudades, comando[2], comando[3])


    elif comando[0]==NUEVA_AEROLINEA:
        if len(comando)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return nueva_aerolinea(aeropuertos_precio, comando[1])


    else:
        return COMANDO_INEXISTENTE




    #hacer variable estado_de_ejecucion?
    return OPERACION_EXITOSA

#----------PROGRAMA PRINCIPAL-------------------

def fly_combi():

    ciudades={}
    #borrar el hash de aeropuertos?
    aeropuertos={}
    aeropuertos_precio=Grafo()
    aeropuertos_tiempo=Grafo()

    if len(sys.argv)!=3:
        print(ERROR)
        return CANTIDAD_INCORRECTA_DE_PARAMETROS

    #Formato aeropuertos: ciudad,codigo_aeropuerto,latitud,longitud
    #Formato vuelos: aeropuerto_i,aeropuerto_j,tiempo_promedio,precio,cant_vuelos_entre_aeropuertos
    with open(str(sys.argv[1]), "r") as f_aeropuertos:
        with open(str(sys.argv[2]), "r") as f_vuelos:
            r_aeropuertos=csv.reader(f_aeropuertos)
            r_vuelos=csv.reader(f_vuelos)

            for row in r_aeropuertos:
                ciudades[row[0]]=[]

                #VER SI NO ES NECESARIO GUARDAR LA LATITUD Y LA LONGITUD
                ciudades[row[0]].append((row[1], row[2], row[3]))
                aeropuertos[row[1]]=(row[0], row[2], row[3])
                aeropuertos_precio.agregar_vertice(row[1])
                aeropuertos_tiempo.agregar_vertice(row[1])

            for row in r_vuelos:
                aeropuertos_precio.agregar_arista(row[0], row[1], int(row[3]))
                aeropuertos_tiempo.agregar_arista(row[0], row[1], int(row[2]))


    #Cambiar porque las ciudades pueden tener nombres distintos
    r_comandos=csv.reader(sys.stdin, delimiter=" ")

    for comando in r_comandos:

        if procesar_comando(comando, ciudades, aeropuertos_tiempo, aeropuertos_precio)==OPERACION_EXITOSA:
            print (OK)
        else:
            print (ERROR)



fly_combi()
