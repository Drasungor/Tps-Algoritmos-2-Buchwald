from grafo import *
import math
import heapq
import queue

#Devuelve una lista con el camino reconstruido desde
#el origen hasta el destino
def reconstruir_camino(padre, destino):
    camino=[]
    camino.append(destino)

    v=padre[destino]

    while v!=None:
        camino.append(v)
        v=padre[v]

    camino.reverse()

    return camino


#Devuelve una lista con los vertices por los que
#se debe pasar para obtener el camino minimo, si
#no se puede llegar desde origen a destino devuelve None
def dijkstra(grafo, origen, destino):

    padre={}
    distancia={}
    heap=[]

    padre[origen]=None

    for v in grafo.obtener_vertices():
        distancia[v]=math.inf

    distancia[origen]=0

    heapq.heappush(heap, (distancia[origen], origen))

    while len(heap)>0:
        v=heapq.heappop(heap)

        if v[1]==destino:
            return reconstruir_camino(padre, destino), distancia[v[1]]

        for w in grafo.adyacentes(v[1]):
            distancia_auxiliar=distancia[v[1]]+grafo.peso_arista(v[1],w)
            if distancia_auxiliar<distancia[w]:
                padre[w]=v[1]
                distancia[w]=distancia_auxiliar
                heapq.heappush(heap, (distancia[w], w))

    return none, none

#Devuelve un diccionaraio de padres que representa
#las conecciones entre los elementos del arbol generado
#por el recorrido
def recorrido_bfs(grafo, origen):

    q=queue.Queue()

    visitados=[]
    padres={}

    q.put(origen)
    visitados.append(origen)
    padres[origen]=None

    while not q.empty():
        v=q.get()
        for w in grafo.adyacentes(v):
            if w not in visitados:
                visitados.append(w)
                padres[w]=v
                q.put(w)

    return padres


#Devuelve una lista con las aristas del arbol de
#tendido minimo generado
def mst(grafo):

    v=grafo.vertice_aleatorio()
    heap=[]
    visitados=[]
    aristas=[]

    for w in grafo.adyacentes(v):
        heapq.heappush(heap, (grafo.peso_arista(v,w), v, w))

    while len(heap)>0:
        (peso_arista, v, w)=heapq.heappop(heap)

        if w in visitados:
            continue

        aristas.append((v, w))
        visitados.append(w)

        for x in grafo.adyacentes(w):
            if x not in visitados:
                heapq.heappush(heap, (grafo.peso_arista(w,x), w, x))


    return aristas            
