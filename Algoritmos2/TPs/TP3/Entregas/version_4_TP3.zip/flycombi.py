#!/usr/bin/python3

from grafo import *
from operaciones_grafo import *
import csv
from constant import *
import sys





def obtener_subcadena(cadena, indice_inicial, caracter_de_corte=None):

    subcadena=""
    if indice_inicial==None or indice_inicial>=len(cadena):
        return None, None

    for i in range(indice_inicial, len(cadena)):
        if cadena[i]==caracter_de_corte:
            return subcadena, i+1
        #subcadena.append(cadena[i])
        subcadena+=cadena[i]

    return subcadena, i+1

#Devuelve una lista que va desde la raiz del
#arbol obtenido por el recorrido hasta el destino
def reconstruir_camino(padres, aeropuerto_destino):

    camino=[aeropuerto_destino]
    v=padres[aeropuerto_destino]

    while v!= None:
        camino.append(v)
        v=padres[v]

    camino.reverse()

    return camino


#Ver si se puede juntar aeropuerto e informacion_aeropuerto
def agregar_punto_kml(archivo_de_salida, aeropuerto, informacion_aeropuerto):

    punto="""\t\t<Placemark>
        <name>""" + aeropuerto + """</name>
        <Point>
            <coordinates>""" + informacion_aeropuerto[1] + "," + informacion_aeropuerto[2] + """</coordinates>
        </Point>
    </Placemark>\n\n"""

    archivo_de_salida.write(punto)


def agregar_camino_kml(archivo_de_salida, informacion_aeropuerto1, informacion_aeropuerto2):

    linea="""\t\t<Placemark>
        <LineString>
            <coordinates>""" + informacion_aeropuerto1[1] + "," + informacion_aeropuerto1[2] + " " + informacion_aeropuerto2[1] + "," + informacion_aeropuerto2[2] + """</coordinates>
        </LineString>
    </Placemark>\n\n"""

    archivo_de_salida.write(linea)



def mejor_camino_a_ciudad_arbol(grafo, aeropuerto_salida, aeropuertos_destino):
    padres=recorrido_bfs(grafo, aeropuerto_salida[0])

    caminos=[]

    for aeropuerto_llegada in aeropuertos_destino:
        #hacer chequeo en reconstruir_camino para ver si el destino esta en
        #el arbol obtenido por bfs, porque el orgien siempre va a estar porque
        #se parte de ahi
        posible_camino=reconstruir_camino(padres, aeropuerto_llegada[0])
        caminos.append(posible_camino)


    if len(caminos)==0:
        return CAMINO_IMPOSIBLE


    mejor_camino=caminos[0]
    escalas_mejor_camino=len(mejor_camino)

    for c in caminos:
        escalas_aux=len(c)
        if escalas_aux<escalas_mejor_camino:
            escalas_mejor_camino=escalas_aux
            mejor_camino=c

    return mejor_camino


#Imprime los elementos de la lista separados con
#el separador
def imprimir_lista_separada(lista, separador):

    largo_lista=len(lista)

    for i in range(largo_lista):
        if i!=largo_lista-1:
            print(lista[i], end=separador)
        else:
            print(lista[i])


def camino_minimo_entre_ciudades(grafo, aeropuertos_origen, aeropuertos_destino):

    peso_minimo=math.inf
    camino_minimo_aux=None
    camino_minimo=None

    for salida in aeropuertos_origen:
        for llegada in aeropuertos_destino:
            camino_minimo_aux, peso_aux=dijkstra(grafo, salida[0], llegada[0])
            if camino_minimo_aux==None:
                continue
            if peso_aux<peso_minimo:
                camino_minimo=camino_minimo_aux

    return camino_minimo

def listar_operaciones():

    #operaciones = [CAMINO_MAS, CAMINO_ESCALAS, NUEVA_AEROLINEA, EXPORTAR_KML, ITINERARIO_CULTURAL, VACACIONES, CENTRALIDAD]
    operaciones = [CAMINO_MAS, CAMINO_ESCALAS, NUEVA_AEROLINEA, EXPORTAR_KML, CENTRALIDAD]

    for elemento in operaciones:
        print (elemento)



def nueva_aerolinea(grafo_por_precio, vuelos, archivo_salida):

    with open(archivo_salida, "w") as ruta_aerolinea:
        writer=csv.writer(ruta_aerolinea)
        aristas= mst(grafo_por_precio)

        for vuelo in aristas:
            pesos_vuelo=(vuelos[vuelo[0]][vuelo[1]][0],vuelos[vuelo[0]][vuelo[1]][1],vuelos[vuelo[0]][vuelo[1]][2])
            writer.writerow(vuelo+pesos_vuelo)

    print(OK)
    return OPERACION_EXITOSA


def centralidad(grafo_por_vuelos, cantidad):

    centralidad_vertices=betweeness_centrality(grafo_por_vuelos)

    centralidades_ordenadas=[]

    for aeropuerto in centralidad_vertices:
        centralidades_ordenadas.append((centralidad_vertices[aeropuerto], aeropuerto))

    centralidades_ordenadas.sort(reverse=True)

    if len(centralidad_vertices)<cantidad:
        cantidad=len(centralidad_vertices)


    #Ver si conviene hacer in range(cantidad-1) e imprimir el ultimo al final
    for i in range(cantidad):
        if i != cantidad-1:
            print(centralidades_ordenadas[i][1], end=", ")
        else:
            print(centralidades_ordenadas[i][1])


def vacaciones(grafo, ciudades, origen, n):

    aeropuertos_origen=[]

    for info_aeropuerto in ciudades[origen]:
        aeropuertos_origen.append(info_aeropuerto[0])

    recorrido=ciclo_de_largo_n(grafo, aeropuertos_origen, n)
    if recorrido!=None:
        imprimir_lista_separada(recorrido, SEPARADOR_CIUDADES)
        return recorrido

    print(RECORRIDO_INEXISTENTE)
    return CAMINO_IMPOSIBLE


def itinerario_cultural(aeropuertos_precio, ruta_archivo, ciudades):

    grafo_ciudades=Grafo()
    grado={}

    with open(ruta_archivo, "r") as itinerario:
        r_itinerario=csv.reader(itinerario)
        a_visitar=next(r_itinerario)

        for ciudad in a_visitar:
            grafo_ciudades.agregar_vertice(ciudad)
            grado[ciudad]=0

        for restricciones in r_itinerario:
            grafo_ciudades.agregar_arista(restricciones[0], restricciones[1], 0)
            grado[restricciones[1]]+=1

    orden_de_visita=orden_topologico(grafo_ciudades, grado)

    if orden_de_visita==None:
        return CAMINO_IMPOSIBLE


    caminos=[]

    cantidad_ciudades=len(a_visitar)


    for ciudad in orden_de_visita:
        if ciudad not in ciudades:
            return CIUDAD_INEXISTENTE

    for i in range(1, cantidad_ciudades):
        #ver si se puede dar el caso en el que se llega por un aeropuerto y se sale por otro
        recorrido_parcial=camino_minimo_entre_ciudades(aeropuertos_precio, ciudades[orden_de_visita[i-1]], ciudades[orden_de_visita[i]])
        #recorrido_parcial=camino_mas(aeropuertos_precio, ciudades, orden_de_visita[i-1], orden_de_visita[i])

        if recorrido_parcial==CAMINO_IMPOSIBLE:
            return CAMINO_IMPOSIBLE

        caminos.append(recorrido_parcial)

    imprimir_lista_separada(orden_de_visita, SEPARADOR_AEROPUERTOS)

    for camino in caminos:
        imprimir_lista_separada(camino, SEPARADOR_AEROPUERTOS)

    return OPERACION_EXITOSA

def exportar_kml(ruta_archivo, posiciones_aeropuertos, ultimo_camino):


    if isinstance(ultimo_camino, list):
        with open(ruta_archivo, "w") as kml:
            kml.write(ENCABEZADO_KML)

            for aeropuerto in ultimo_camino:
                agregar_punto_kml(kml, aeropuerto, posiciones_aeropuertos[aeropuerto])

            for i in range(1, len(ultimo_camino)):
                agregar_camino_kml(kml, posiciones_aeropuertos[ultimo_camino[i-1]], posiciones_aeropuertos[ultimo_camino[i]])

            kml.write(FIN_KML)

        print(OK)

    else:
        print(ERROR)


def camino_escalas(grafo, ciudades, origen, destino):


    if origen not in ciudades or destino not in ciudades:
        return CIUDAD_INEXISTENTE


    padres=[]
    cantidad_escalas = math.inf
    mejor_camino=[]

    """
    for v in ciudades[origen]:

        #ARREGLAR PORQUE NO IMPORTA EL DESTINO EN ESTE CASO
        #DE LA MISMA FORMA QUE EN DIJKSTRA
        for w in ciudades[destino]:
            padres_auxiliar=recorrido_bfs(grafo, v)
            cantidad_escalas_aux=len(padres_auxiliar)
            if cantidad_escalas_aux<cantidad_escalas:
                cantidad_escalas=cantidad_escalas_aux
                padres=padres_auxiliar
    """

    for aeropuerto_salida in ciudades[origen]:
        mejor_camino_actual=mejor_camino_a_ciudad_arbol(grafo, aeropuerto_salida, ciudades[destino])
        cantidad_escalas_aux=len(mejor_camino_actual)
        if cantidad_escalas_aux<cantidad_escalas:
            cantidad_escalas=cantidad_escalas_aux
            mejor_camino=mejor_camino_actual

    imprimir_lista_separada(mejor_camino, SEPARADOR_AEROPUERTOS)

    return mejor_camino


def camino_mas(grafo, ciudades, origen, destino):

    if origen not in ciudades or destino not in ciudades:
        return CIUDAD_INEXISTENTE

    camino_minimo=camino_minimo_entre_ciudades(grafo, ciudades[origen], ciudades[destino])

    if camino_minimo==None:
        return CAMINO_IMPOSIBLE

    imprimir_lista_separada(camino_minimo, SEPARADOR_AEROPUERTOS)

    return camino_minimo



#MANDAR UNA NUPLA CON LOS 3 GRAFOS EN VEZ DE MANDAR LOS 3 GRAFOS POR SEPARADO
def procesar_comando(linea, ciudades, posiciones_aeropuertos, aeropuertos_tiempo, aeropuertos_precio, aeropuertos_cantidad_vuelos, vuelos, retorno_previo):

    #BORRAR
    #print("Comando: ", linea)

    comando,siguiente_indice=obtener_subcadena(linea, 0, " ")


    """
    if len(comando)==0:
        return CANTIDAD_INCORRECTA_DE_PARAMETROS
    """

    if comando==LISTAR_OPERACIONES:
        listar_operaciones()

    elif comando==CAMINO_ESCALAS:

        origen, siguiente_indice=obtener_subcadena(linea, siguiente_indice, SEPARADOR_CIUDADES)
        destino, siguiente_indice=obtener_subcadena(linea, siguiente_indice)

        if origen==None or destino==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        if origen not in ciudades or destino not in ciudades:
            return CIUDAD_INEXISTENTE

        return camino_escalas(aeropuertos_tiempo, ciudades, origen, destino)

    elif comando==CAMINO_MAS:
        modo, siguiente_indice=obtener_subcadena(linea, siguiente_indice, " ")
        origen, siguiente_indice=obtener_subcadena(linea, siguiente_indice, SEPARADOR_CIUDADES)
        destino, siguiente_indice=obtener_subcadena(linea, siguiente_indice)

        if modo==None or origen==None or destino==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        if origen not in ciudades or destino not in ciudades:
            return CIUDAD_INEXISTENTE

        if modo==BARATO:
            return camino_mas(aeropuertos_precio, ciudades, origen, destino)
        elif modo==RAPIDO:
            return camino_mas(aeropuertos_tiempo, ciudades, origen, destino)

    elif comando==NUEVA_AEROLINEA:

        ruta_archivo, siguiente_indice=obtener_subcadena(linea, siguiente_indice)

        if ruta_archivo==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return nueva_aerolinea(aeropuertos_precio, vuelos, ruta_archivo)


    #PASAR TODOS ESTOS RETURNS DE FUNCIONES QUE NO DEVUELVEN NADA
    #AL FINAL DE LA FUNCION
    elif comando==CENTRALIDAD:

        cantidad, siguiente_indice=obtener_subcadena(linea, siguiente_indice)

        if cantidad==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        try:
            cantidad=int(cantidad)
            centralidad(aeropuertos_cantidad_vuelos, cantidad)
        except ValueError:
            return PARAMETROS_INCORRECTOS

        return OPERACION_EXITOSA

    elif comando==EXPORTAR_KML:

        ruta_archivo, siguiente_indice=obtener_subcadena(linea, siguiente_indice)

        if ruta_archivo==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        exportar_kml(ruta_archivo, posiciones_aeropuertos, retorno_previo)
        return OPERACION_EXITOSA

    elif comando==ITINERARIO_CULTURAL:

        ruta_archivo, siguiente_indice=obtener_subcadena(linea, siguiente_indice)

        if ruta_archivo==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return itinerario_cultural(aeropuertos_tiempo, ruta_archivo, ciudades)

    elif comando==VACACIONES:
        origen, siguiente_indice=obtener_subcadena(linea, siguiente_indice, ",")
        cantidad, siguiente_indice=obtener_subcadena(linea, siguiente_indice)


        if origen==None:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        if origen not in ciudades:
            return CIUDAD_INEXISTENTE

        try:
            cantidad=int(cantidad)
            return vacaciones(aeropuertos_precio, ciudades, origen, cantidad)
        except ValueError:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

    else:
        return COMANDO_INEXISTENTE


    """
    if comando[0]==LISTAR_OPERACIONES:
        listar_operaciones()

    elif comando[0]==CAMINO_ESCALAS:

        if len(comando)!=3:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return camino_escalas(aeropuertos_tiempo, ciudades, comando[1], comando[2])

    elif comando[0]==CAMINO_MAS:

        if len(comando)!=3:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        ciudades_extrmo=comando[3].split(SEPARADOR_CIUDADES)

        if len(ciudades_extrmo)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS



        if comando[2] not in ciudades or comando[3] not in ciudades:
            return PARAMETROS_INCORRECTOS

        if comando[1]==BARATO:
            return camino_mas(aeropuertos_precio, ciudades, comando[2], comando[3])
        elif comando[1]==RAPIDO:
            return camino_mas(aeropuertos_tiempo, ciudades, comando[2], comando[3])

    elif comando[0]==NUEVA_AEROLINEA:
        if len(comando)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return nueva_aerolinea(aeropuertos_precio, comando[1])


    #PASAR TODOS ESTOS RETURNS DE FUNCIONES QUE NO DEVUELVEN NADA
    #AL FINAL DE LA FUNCION
    elif comando[0]==CENTRALIDAD:
        if len(comando)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        if int(comando[1])<0:
            return PARAMETROS_INCORRECTOS

        centralidad(aeropuertos_cantidad_vuelos, int(comando[1]))

        return OPERACION_EXITOSA

    elif comando[0]==EXPORTAR_KML:
        if len(comando)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS
        exportar_kml(comando[1], posiciones_aeropuertos, retorno_previo)
        return OPERACION_EXITOSA


    elif comando[0]==ITINERARIO_CULTURAL:
        if len(comando)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS

        return itinerario_cultural(aeropuertos_precio, comando[1], ciudades)

    elif comando[0]==VACACIONES:
        if len(comando)!=2:
            return CANTIDAD_INCORRECTA_DE_PARAMETROS



    else:
        return COMANDO_INEXISTENTE

    """


    #hacer variable estado_de_ejecucion?
    return OPERACION_EXITOSA

#----------PROGRAMA PRINCIPAL-------------------

def fly_combi():

    ciudades={}
    #borrar el hash de aeropuertos?
    posiciones_aeropuertos={}
    aeropuertos_precio=Grafo()
    aeropuertos_tiempo=Grafo()
    aeropuertos_cantidad_vuelos=Grafo()
    vuelos={}

    if len(sys.argv)!=3:
        print(ERROR)
        return CANTIDAD_INCORRECTA_DE_PARAMETROS

    #Formato aeropuertos: ciudad,codigo_aeropuerto,latitud,longitud
    #Formato vuelos: aeropuerto_i,aeropuerto_j,tiempo_promedio,precio,cant_vuelos_entre_aeropuertos
    with open(str(sys.argv[1]), "r") as f_aeropuertos:
        with open(str(sys.argv[2]), "r") as f_vuelos:
            r_aeropuertos=csv.reader(f_aeropuertos)
            r_vuelos=csv.reader(f_vuelos)

            for row in r_aeropuertos:
                ciudades[row[0]]=[]

                #VER SI NO ES NECESARIO GUARDAR LA LATITUD Y LA LONGITUD EN CIUDADES
                ciudades[row[0]].append((row[1], row[2], row[3]))
                posiciones_aeropuertos[row[1]]=(row[0], row[2], row[3])
                aeropuertos_precio.agregar_vertice(row[1])
                aeropuertos_tiempo.agregar_vertice(row[1])
                aeropuertos_cantidad_vuelos.agregar_vertice(row[1])
                vuelos[row[1]]={}

            for row in r_vuelos:
                aeropuertos_precio.agregar_arista(row[0], row[1], int(row[3]))
                aeropuertos_tiempo.agregar_arista(row[0], row[1], int(row[2]))
                aeropuertos_cantidad_vuelos.agregar_arista(row[0], row[1], 1.0/float(row[4]))
                vuelos[row[0]][row[1]]=(row[2], row[3], row[4])
                vuelos[row[1]][row[0]]=(row[2], row[3], row[4])


    #Cambiar porque las ciudades pueden tener nombres distintos
    #r_comandos=csv.reader(sys.stdin, delimiter=" ")



    retorno=None

    #for comando in r_comandos:
    for linea in sys.stdin:
        linea=linea[:len(linea)-1]
        #hacer una nupla con los grafos
        retorno=procesar_comando(linea, ciudades, posiciones_aeropuertos, aeropuertos_tiempo, aeropuertos_precio, aeropuertos_cantidad_vuelos, vuelos, retorno)


fly_combi()
